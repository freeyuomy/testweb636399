<?php
namespace App;

use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;
use React\MySQL\Factory;

class Chat implements MessageComponentInterface
{
    protected $clients;
    protected $mysql;
    
    public function __construct($dbConfig)
    {
        $this->clients = new \SplObjectStorage;
        
        // Initialize MySQL connection
        $factory = new Factory();
        $uri = "mysql://{$dbConfig['username']}:{$dbConfig['password']}@{$dbConfig['host']}/{$dbConfig['database']}";
        $this->mysql = $factory->createLazyConnection($uri);
        
        echo "WebSocket server started!\n";
    }

    public function onOpen(ConnectionInterface $conn)
    {
        // Store the new connection
        $this->clients->attach($conn);
        
        $userId = $this->generateUserId();
        $conn->userId = $userId;
        
        // Store user connection in database
        $this->mysql->query(
            'INSERT INTO connections (user_id, connected_at) VALUES (?, NOW())',
            [$userId]
        );
        
        echo "New connection! ({$conn->resourceId})\n";
        
        // Broadcast to all clients about new connection
        $this->broadcastMessage([
            'type' => 'connection',
            'userId' => $userId,
            'message' => "User {$userId} has joined the chat",
            'timestamp' => date('Y-m-d H:i:s')
        ]);
    }

    public function onMessage(ConnectionInterface $from, $msg)
    {
        $data = json_decode($msg, true);
        
        if (!$data || !isset($data['message'])) {
            return;
        }
        
        $userId = $from->userId;
        $message = $data['message'];
        
        // Store message in database
        $this->mysql->query(
            'INSERT INTO messages (user_id, message, sent_at) VALUES (?, ?, NOW())',
            [$userId, $message]
        );
        
        echo "User {$userId} sent message: {$message}\n";
        
        // Broadcast the message to all clients
        $this->broadcastMessage([
            'type' => 'message',
            'userId' => $userId,
            'message' => $message,
            'timestamp' => date('Y-m-d H:i:s')
        ]);
    }

    public function onClose(ConnectionInterface $conn)
    {
        // Remove the connection
        $this->clients->detach($conn);
        
        $userId = $conn->userId;
        
        // Update database that user disconnected
        $this->mysql->query(
            'UPDATE connections SET disconnected_at = NOW() WHERE user_id = ? AND disconnected_at IS NULL',
            [$userId]
        );
        
        echo "Connection {$conn->resourceId} has disconnected\n";
        
        // Broadcast to all clients about disconnection
        $this->broadcastMessage([
            'type' => 'disconnection',
            'userId' => $userId,
            'message' => "User {$userId} has left the chat",
            'timestamp' => date('Y-m-d H:i:s')
        ]);
    }

    public function onError(ConnectionInterface $conn, \Exception $e)
    {
        echo "An error has occurred: {$e->getMessage()}\n";
        
        $conn->close();
    }
    
    protected function broadcastMessage($data)
    {
        $message = json_encode($data);
        
        foreach ($this->clients as $client) {
            $client->send($message);
        }
    }
    
    protected function generateUserId()
    {
        return uniqid('user_');
    }
} 