<?php
// Database configuration
return [
    'host' => 'localhost',
    'username' => 'websocket_user', // Change this to your MySQL username
    'password' => 'your_password',  // Change this to your MySQL password
    'database' => 'websocket_chat'  // Database name
]; 