-- Create database
CREATE DATABASE IF NOT EXISTS websocket_chat;

-- Use the database
USE websocket_chat;

-- Create tables
CREATE TABLE IF NOT EXISTS connections (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(50) NOT NULL,
    connected_at DATETIME NOT NULL,
    disconnected_at DATETIME NULL,
    INDEX (user_id)
);

CREATE TABLE IF NOT EXISTS messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(50) NOT NULL,
    message TEXT NOT NULL,
    sent_at DATETIME NOT NULL,
    INDEX (user_id),
    INDEX (sent_at)
);

-- Create a user for the WebSocket application
-- Note: Replace 'your_password' with a secure password
CREATE USER IF NOT EXISTS 'websocket_user'@'localhost' IDENTIFIED BY 'your_password';
GRANT ALL PRIVILEGES ON websocket_chat.* TO 'websocket_user'@'localhost';
FLUSH PRIVILEGES; 