# WebSocket Chat Application with PHP, MySQL, and Nginx

This is a simple WebSocket chat application built with PHP, MySQL, and configured for Nginx with aaPanel.

## Requirements

- PHP 7.4 or higher
- MySQL/MariaDB
- Nginx with aaPanel
- Composer

## Installation

1. Clone this repository to your server:

```bash
# Either clone from your repository
git clone https://github.com/yourusername/websocket-chat.git
cd websocket-chat

# Or create a new directory and copy the files
mkdir websocket-chat
cd websocket-chat
```

2. Install dependencies:

```bash
composer install
```

3. Set up the database:

- Create a MySQL database and user using the SQL in `database/setup.sql`
- Update the database configuration in `config/database.php`

4. Configure Nginx:

- In aaPanel, go to the website management section
- Find your website and click on "Settings"
- Go to the "Rewrite" section and add a new rewrite rule
- Copy the contents from `nginx/websocket.conf` and adjust as needed
- Make sure to update the server_name and root path in the configuration

5. Start the WebSocket server:

```bash
php bin/server.php
```

For production, you should use a process manager like Supervisor to keep the WebSocket server running.

## Supervisor Configuration

Create a supervisor configuration file:

```ini
[program:websocket-server]
command=php /path/to/your/project/bin/server.php
directory=/path/to/your/project
autostart=true
autorestart=true
stderr_logfile=/path/to/your/project/logs/websocket-err.log
stdout_logfile=/path/to/your/project/logs/websocket-out.log
user=www-data
```

## Usage

1. Access the chat application by visiting your domain in a web browser
2. The WebSocket client will automatically connect to the server
3. Start chatting!

## Features

- Real-time chat with WebSocket
- Persistent message storage in MySQL database
- User connection tracking
- Auto-reconnect on connection loss

## Customization

- Modify the `src/Chat.php` file to add more features
- Customize the frontend in `public/index.html`
- Add authentication by extending the WebSocket handler

## License

MIT 